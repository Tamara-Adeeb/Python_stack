from django.apps import AppConfig


class LogAndRegConfig(AppConfig):
    name = 'log_and_reg'
